# retro-baselines

This is a set of baseline algorithms for the [Retro Contest](https://github.com/openai/retro-contest).

Also see [sonic-on-ray](https://github.com/openai/sonic-on-ray), which uses [Ray](https://github.com/ray-project/ray), a library for distributed execution.